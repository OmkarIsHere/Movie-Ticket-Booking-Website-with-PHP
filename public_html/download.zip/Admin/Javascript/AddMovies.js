// function fileUpload1(val) {
//     alert(val);
// }

// function fileUploaded2(val) {
//     alert(val);
// }

// (function(window, document, undefined) {

//     // code that should be taken care of right away

//     window.onload = init;

//     function init() {

//     }
// })(window, document, undefined);