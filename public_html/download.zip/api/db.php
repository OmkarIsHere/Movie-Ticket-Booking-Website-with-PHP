
<?php
$servername = "localhost";
$username = "id20121598_root";
$password = "Movietime@123";
$Database = "id20121598_movietime";
$conn=mysqli_connect($servername,$username,$password,$Database);
?>