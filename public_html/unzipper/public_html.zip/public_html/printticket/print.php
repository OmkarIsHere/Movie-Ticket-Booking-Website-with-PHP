<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Ticket</title>
    <!-- <script src="../js/jquery.js"></script> -->
    <link rel="stylesheet" href='../css/print.css'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<?php
require '../payment/config_mysqli.php';

session_start();

if (isset($_SESSION["showid"])) {
    if (isset($_SESSION["theaterid"])) {
        $theater_id = $_SESSION["theaterid"];
        $show_id = $_SESSION["showid"];
        $sql_last_no = "SELECT ScreenNo FROM `shows` WHERE ShowId = '$show_id' && TheaterId = '$theater_id';";
        $result_id = mysqli_query($conn, $sql_last_no);
        $row = mysqli_fetch_assoc($result_id);
        $ScreenNo = $row['ScreenNo'];
        $_SESSION['ScreenNo'] = $ScreenNo;
    }
}

ob_start();
$moviename = "N/A";
$theatername = "N/A";
$city = "N/A";
$date = "N/A";
$time = "N/A";
$totalAmt = "N/A";
$seat = "N/A";
$screen = "N/A";
$gst = "N/A";
$conveniencefees = "N/A";
$transactionid = "N/A";

if (isset($_SESSION["moviename"])) {
    $moviename = $_SESSION["moviename"];
}
if (isset($_SESSION["theatername"])) {
    $theatername = $_SESSION["theatername"];
}
if (isset($_SESSION["city"])) {
    $city = $_SESSION["city"];
}
if (isset($_SESSION["date"])) {
    $date = $_SESSION["date"];
}
if (isset($_SESSION["time"])) {
    $time = $_SESSION["time"];
}
if (isset($_SESSION["total"])) {
    $totalAmt = $_SESSION["total"];
}
if (isset($_SESSION["AllSeatType"])) {
    $seat = $_SESSION["AllSeatType"];
}
if (isset($_SESSION["ScreenNo"])) {
    $screen = $_SESSION["ScreenNo"];
}
if (isset($_SESSION["conv_fees"])) {
    $conveniencefees = $_SESSION["conv_fees"];
}
if (isset($_SESSION["gst"])) {
    $gst = $_SESSION["gst"];
}
if (isset($_SESSION["tid"])) {
    $transactionid = $_SESSION["tid"];
}
?>

<body>
    <section id="pre-loader">
        <div class="dots">
          <span style="--i:1;"></span>
          <span style="--i:2;"></span>
          <span style="--i:3;"></span>
          <span style="--i:4;"></span>
          <span style="--i:5;"></span>
          <span style="--i:6;"></span>
          <span style="--i:7;"></span>
          <span style="--i:8;"></span>
          <span style="--i:9;"></span>
          <span style="--i:10;"></span>
          <span style="--i:11;"></span>
          <span style="--i:12;"></span>
          <span style="--i:13;"></span>
          <span style="--i:14;"></span>
          <span style="--i:15;"></span>
        </div>
        <div class="loader-text">
            <h4>Please Wait...</h4>
        </div>
    </section>

    <section id="load-html">
        <div class="container">
            <img id="ticket" src="../img/ticket.png" alt="Ticket">
            <img id="logo" src="../img/MOVIEtime_black.png" alt="LOGO">
            <h3 id="moviename"><?php echo $moviename ?></h3>
            <h4 id="theatername"><?php echo $theatername ?>,&nbsp;<?php echo $city ?></h4>
            <p id="datetime"><strong>Date :</strong>&nbsp;<?php echo $date ?>&nbsp; <strong><?php echo $time ?></strong> </p>
            <p id="seat"> <b>SEATS :</b>&nbsp; <?php echo $seat ?></p>
            <p id="screen"><b>SCREEN NO :</b>&nbsp; <?php echo $screen ?></p>
            <p id="transactionid"><b>TRANSACTION NO :</b>&nbsp;<?php echo $transactionid ?></p>
            <p id="convfees"><b>CONVENIENCE FEES :</b>&nbsp;<?php echo $conveniencefees ?></p>
            <p id="gst"><b>GST NO :</b>&nbsp;<?php echo $gst ?></p>
            <p id="totalamt"><b>TOTAL :</b>&nbsp;Rs. &nbsp; <?php echo $totalAmt ?></p>
            <div class="div2">
                <a href="../Ticket.php" id="print">Download</a>
                <a href="../index.php" id="home">Home</a>
            </div>
        </div>
    </section>

    <script>
        window.onload = function () {
            var pre_loader = document.getElementById("pre-loader");
            var load_html = document.getElementById("load-html");

            load_html.style.display = 'block';
            pre_loader.style.display = 'none';

        }

        function paymentStatus(message,logo) {
            swal({
                title: "Good Job!",
                text: message,
                icon: logo,
                button: "OK",
            }).then((value) => {
            // swal(`The returned value is: ${value}`);
            if(`${value}`) {
                if(logo == "error") {
                    window.location.href = '../index.php';
                }
            }
            });
        }

    </script>

    <?php
        if (isset($_SESSION['paymentStatus']) && $_SESSION['paymentStatus'] == 'Pending') {
            $_SESSION['paymentStatus'] = 'Done';
            echo '<script>paymentStatus("Payment Successful","success");</script>';
        }
        if (isset($_SESSION['paymentStatus']) && $_SESSION['paymentStatus'] == 'Failed') {
            echo '<script>paymentStatus("Payment Failed","error");</script>';
        }
    ?>
</body>

</html>