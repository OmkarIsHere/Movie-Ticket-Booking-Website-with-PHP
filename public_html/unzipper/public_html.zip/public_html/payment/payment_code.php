<?php
if (!isset($_SESSION['logged_in'])) {
    header('Location: ../Login/login.php');
}
?>
