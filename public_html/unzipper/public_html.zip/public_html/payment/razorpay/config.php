<?php
$keyId = 'rzp_test_Fn4uJmdo9qlGIG';
$keySecret = 'jcgIPtGFBdoWdmt3DVC1Gb6l';
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors', 0);
