let CheckValue = 0;
let CheckStatus;
let amt = 0;
let id;
let temp_ticket_numb = "";
let ticket_numb1 = "";
let ticket_numb2 = "";
let ticket_numb3 = "";
let ticket_numb4 = "";
let ticket_numb5 = "";
let t1_id = "";
let t2_id = "";
let t3_id = "";
let t4_id = "";
let t5_id = "";
let count = 0;

/* to find the selected seats so it is possible to disable other seats if user selects 5 tickets  */
function retrieve_id(ele) {
    id = ele.id;
    CheckStatus = document.getElementById(id);
    document.getElementById("pay").style.visibility = "visible";
    document.getElementById("header-btns").style.visibility = "visible";
    numb_of_ticket();
    if (ele.id == "A10" ||
        ele.id == "A11" ||
        ele.id == "A12" ||

        ele.id == "B10" ||
        ele.id == "B11" ||
        ele.id == "B12" ||

        ele.id == "C10" ||
        ele.id == "C11" ||
        ele.id == "C12" ||

        ele.id == "D10" ||
        ele.id == "D11" ||
        ele.id == "D12" ||

        ele.id == "E10" ||
        ele.id == "E11" ||
        ele.id == "E12" ||

        ele.id == "F10" ||
        ele.id == "F11" ||
        ele.id == "F12" ||

        ele.id == "G10" ||
        ele.id == "G11" ||
        ele.id == "G12" ||

        ele.id == "H10" ||
        ele.id == "H11" ||
        ele.id == "H12" ||

        ele.id == "I10" ||
        ele.id == "I11" ||
        ele.id == "I12" ||

        ele.id == "J10" ||
        ele.id == "J11" ||
        ele.id == "J12" ||

        ele.id == "K10" ||
        ele.id == "K11" ||
        ele.id == "K12") {
        for (i = 4; i <= 6; i++) {
            temp_ticket_numb += String(document.getElementById(id).value)[i];
        }
    } else {
        for (i = 4; i <= 5; i++) {
            temp_ticket_numb += String(document.getElementById(id).value)[i];
        }
    }
    if (CheckStatus.checked) {
        count += 1;
        if (count == 1) {
            ticket_numb1 = temp_ticket_numb;
            t1_id = id;
        }
        if (count == 2) {
            ticket_numb2 = temp_ticket_numb;
            t2_id = id;
        }
        if (count == 3) {
            ticket_numb3 = temp_ticket_numb;
            t3_id = id;
        }
        if (count == 4) {
            ticket_numb4 = temp_ticket_numb;
            t4_id = id;
        }
        if (count == 5) {
            ticket_numb5 = temp_ticket_numb;
            t5_id = id;
        }
        if (count == 5) {
            disable_unable(1);
            document.getElementById(t1_id).disabled = false;
            document.getElementById(t2_id).disabled = false;
            document.getElementById(t3_id).disabled = false;
            document.getElementById(t4_id).disabled = false;
            document.getElementById(t5_id).disabled = false;
        }
        temp_ticket_numb = "";

    } else {
        count -= 1;
        if (count == 0) {
            document.getElementById("pay").style.visibility = "hidden";

        }
        if (id == t1_id) {
            ticket_numb1 = ticket_numb2;
            ticket_numb2 = ticket_numb3;
            ticket_numb3 = ticket_numb4;
            ticket_numb4 = ticket_numb5;

            t1_id = t2_id;
            t2_id = t3_id;
            t3_id = t4_id;
            t4_id = t5_id;
        }
        if (id == t2_id) {
            ticket_numb2 = ticket_numb3;
            ticket_numb3 = ticket_numb4;
            ticket_numb4 = ticket_numb5;

            t2_id = t3_id;
            t3_id = t4_id;
            t4_id = t5_id;
        }
        if (id == t3_id) {
            ticket_numb3 = ticket_numb4;
            ticket_numb4 = ticket_numb5;

            t3_id = t4_id;
            t4_id = t5_id;
        }
        if (id == t4_id) {
            ticket_numb4 = ticket_numb5;

            t4_id = t5_id;
        }
        ticket_numb5 = "";
        t5_id = "";
        temp_ticket_numb = "";
        disable_unable(0);
    }

};

/* to find number of tickets selected by user and display it. */
function numb_of_ticket() {
    if (CheckStatus.checked) {
        CheckValue += 1;
        document.getElementById("selected-tickets").innerHTML = CheckValue;
        pay_inc();
    } else {
        if (document.getElementById("selected-tickets").innerHTML == 0) {
            var markedCheckbox = document.querySelectorAll('input[type="checkbox"]:checked');
            for (var checkbox of markedCheckbox) {
                CheckValue += 1;
            }
            CheckValue += 1;
            document.getElementById("selected-tickets").innerHTML = CheckValue;
        }
        CheckValue -= 1;
        document.getElementById("selected-tickets").innerHTML = CheckValue;
        pay_dec();
    }
};

/* to find amount of selected seats */
function pay_inc() {
    var amt_str = document.getElementById(id).value;
    amt += parseInt(amt_str)
    document.getElementById("total-pay").innerHTML = amt;
};

function pay_dec() {
    if (document.getElementById("total-pay").innerHTML == 0) {
        var markedCheckbox = document.querySelectorAll('input[type="checkbox"]:checked');
        for (var checkbox of markedCheckbox) {
            for (i = 0; i <= 2; i++) {
                temp_amount += checkbox.value[i];
            }
            amount += Number(temp_amount);
            temp_amount = "";
        }
        amt = Number(amount) + parseInt(document.getElementById(id).value);
        document.getElementById("total-pay").innerHTML = amt;
    }

    var amt_str = document.getElementById(id).value;
    amt -= parseInt(amt_str)
    document.getElementById("total-pay").innerHTML = amt;
};

/* to disable the other seats when user select 5 tickets */
function disable_unable(val) {
    document.getElementById("A1").disabled = val;
    document.getElementById("A2").disabled = val;
    document.getElementById("A3").disabled = val;
    document.getElementById("A4").disabled = val;
    document.getElementById("A5").disabled = val;
    document.getElementById("A6").disabled = val;
    document.getElementById("A7").disabled = val;
    document.getElementById("A8").disabled = val;
    document.getElementById("A9").disabled = val;
    document.getElementById("A10").disabled = val;
    document.getElementById("A11").disabled = val;
    document.getElementById("A12").disabled = val;

    document.getElementById("B1").disabled = val;
    document.getElementById("B2").disabled = val;
    document.getElementById("B3").disabled = val;
    document.getElementById("B4").disabled = val;
    document.getElementById("B5").disabled = val;
    document.getElementById("B6").disabled = val;
    document.getElementById("B7").disabled = val;
    document.getElementById("B8").disabled = val;
    document.getElementById("B9").disabled = val;
    document.getElementById("B10").disabled = val;
    document.getElementById("B11").disabled = val;
    document.getElementById("B12").disabled = val;

    document.getElementById("C1").disabled = val;
    document.getElementById("C2").disabled = val;
    document.getElementById("C3").disabled = val;
    document.getElementById("C4").disabled = val;
    document.getElementById("C5").disabled = val;
    document.getElementById("C6").disabled = val;
    document.getElementById("C7").disabled = val;
    document.getElementById("C8").disabled = val;
    document.getElementById("C9").disabled = val;
    document.getElementById("C10").disabled = val;
    document.getElementById("C11").disabled = val;
    document.getElementById("C12").disabled = val;

    document.getElementById("D1").disabled = val;
    document.getElementById("D2").disabled = val;
    document.getElementById("D3").disabled = val;
    document.getElementById("D4").disabled = val;
    document.getElementById("D5").disabled = val;
    document.getElementById("D6").disabled = val;
    document.getElementById("D7").disabled = val;
    document.getElementById("D8").disabled = val;
    document.getElementById("D9").disabled = val;
    document.getElementById("D10").disabled = val;
    document.getElementById("D11").disabled = val;
    document.getElementById("D12").disabled = val;

    document.getElementById("E1").disabled = val;
    document.getElementById("E2").disabled = val;
    document.getElementById("E3").disabled = val;
    document.getElementById("E4").disabled = val;
    document.getElementById("E5").disabled = val;
    document.getElementById("E6").disabled = val;
    document.getElementById("E7").disabled = val;
    document.getElementById("E8").disabled = val;
    document.getElementById("E9").disabled = val;
    document.getElementById("E10").disabled = val;
    document.getElementById("E11").disabled = val;
    document.getElementById("E12").disabled = val;

    document.getElementById("F1").disabled = val;
    document.getElementById("F2").disabled = val;
    document.getElementById("F3").disabled = val;
    document.getElementById("F4").disabled = val;
    document.getElementById("F5").disabled = val;
    document.getElementById("F6").disabled = val;
    document.getElementById("F7").disabled = val;
    document.getElementById("F8").disabled = val;
    document.getElementById("F9").disabled = val;
    document.getElementById("F10").disabled = val;
    document.getElementById("F11").disabled = val;
    document.getElementById("F12").disabled = val;

    document.getElementById("G1").disabled = val;
    document.getElementById("G2").disabled = val;
    document.getElementById("G3").disabled = val;
    document.getElementById("G4").disabled = val;
    document.getElementById("G5").disabled = val;
    document.getElementById("G6").disabled = val;
    document.getElementById("G7").disabled = val;
    document.getElementById("G8").disabled = val;
    document.getElementById("G9").disabled = val;
    document.getElementById("G10").disabled = val;
    document.getElementById("G11").disabled = val;
    document.getElementById("G12").disabled = val;

    document.getElementById("H1").disabled = val;
    document.getElementById("H2").disabled = val;
    document.getElementById("H3").disabled = val;
    document.getElementById("H4").disabled = val;
    document.getElementById("H5").disabled = val;
    document.getElementById("H6").disabled = val;
    document.getElementById("H7").disabled = val;
    document.getElementById("H8").disabled = val;
    document.getElementById("H9").disabled = val;
    document.getElementById("H10").disabled = val;
    document.getElementById("H11").disabled = val;
    document.getElementById("H12").disabled = val;

    document.getElementById("I1").disabled = val;
    document.getElementById("I2").disabled = val;
    document.getElementById("I3").disabled = val;
    document.getElementById("I4").disabled = val;
    document.getElementById("I5").disabled = val;
    document.getElementById("I6").disabled = val;
    document.getElementById("I7").disabled = val;
    document.getElementById("I8").disabled = val;
    document.getElementById("I9").disabled = val;
    document.getElementById("I10").disabled = val;
    document.getElementById("I11").disabled = val;
    document.getElementById("I12").disabled = val;

    document.getElementById("J1").disabled = val;
    document.getElementById("J2").disabled = val;
    document.getElementById("J3").disabled = val;
    document.getElementById("J4").disabled = val;
    document.getElementById("J5").disabled = val;
    document.getElementById("J6").disabled = val;
    document.getElementById("J7").disabled = val;
    document.getElementById("J8").disabled = val;
    document.getElementById("J9").disabled = val;
    document.getElementById("J10").disabled = val;
    document.getElementById("J11").disabled = val;
    document.getElementById("J12").disabled = val;

    document.getElementById("K1").disabled = val;
    document.getElementById("K2").disabled = val;
    document.getElementById("K3").disabled = val;
    document.getElementById("K4").disabled = val;
    document.getElementById("K5").disabled = val;
    document.getElementById("K6").disabled = val;
    document.getElementById("K7").disabled = val;
    document.getElementById("K8").disabled = val;
    document.getElementById("K9").disabled = val;
    document.getElementById("K10").disabled = val;
    document.getElementById("K11").disabled = val;
    document.getElementById("K12").disabled = val;
};